/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'toolbar', 'bg', {
	toolbarCollapse: 'Свиване на лентата с инструменти',
	toolbarExpand: 'Разширяване на лентата с инструменти',
	toolbarGroups: {
		document: 'Документ',
		clipboard: 'Клипборд/Отмяна',
		editing: 'Промяна',
		forms: 'Форми',
		basicstyles: 'Базови стилове',
		paragraph: 'Параграф',
		links: 'Връзки',
		insert: 'Вмъкване',
		styles: 'Стилове',
		colors: 'Цветове',
		tools: 'Инструменти'
	},
	toolbars: 'Ленти с инструменти'
} );
