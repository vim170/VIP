/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'toolbar', 'sq', {
	toolbarCollapse: 'Zvogëlo Shiritin',
	toolbarExpand: 'Zgjero Shiritin',
	toolbarGroups: {
		document: 'Dokument',
		clipboard: 'Tabela Punës/Ribëje',
		editing: 'Duke Redaktuar',
		forms: 'Formular',
		basicstyles: 'Stili Bazë',
		paragraph: 'Paragraf',
		links: 'Nyjet',
		insert: 'Shto',
		styles: 'Stil',
		colors: 'Ngjyrat',
		tools: 'Mjetet'
	},
	toolbars: 'Shiritet e Redaktuesit'
} );
